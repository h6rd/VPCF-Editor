@echo off
set compiler=C:\Program Files (x86)\Steam\steamapps\common\dota 2 beta\game\bin\win64\resourcecompiler.exe
"%compiler%" -r "C:\Program Files (x86)\Steam\steamapps\common\dota 2 beta\content\dota_addons\img_compiler\panorama\images\*.*"